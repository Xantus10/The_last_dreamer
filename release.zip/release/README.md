# The last dreamer  

Simple C++ game developed with SFML.  

## LICENSE  

Everything in this project is under CC0 (specified in LICENSE.txt), with the exceptions of:  
a) Fonts under src/assets/fonts, they are for the most part under OFL, but consult their separate license files for details (They are in form of LICENSE-"NameOfFontHere".txt in the same folder)
b) .dll files prefixed with sfml as well as openal32.dll inside release.zip, they have their license text in "sfml-LICENSE.txt", inside the zip and also availible on https://www.sfml-dev.org/license.php
c) Fonts inside release.zip under assets/fonts, they follow the same rule as point 'a'

### NOTICE  

This project is in alpha stage and it is availible in release.zip as Final.exe 
